
<?php

include 'db_connection.php';

	$id = $_GET['id'];

	$id= $id;
	$idN="";
	$lastID = $id + 5;
	
	$sql = "SELECT * from songs where id>$id limit 5";
	$result = mysqli_query ($conn,$sql); 
	while($row = mysqli_fetch_array($result)){
	
	$idN=$row["id"];				
 ?>
					
					<div class="col-md-12" style="margin-bottom:20px; border:1px solid grey; border-radius:10px; padding-left:0px!important; padding-right:0px!important;">
		
							<div class="col-md-12" style="padding:10px; width:100%;">
								<span style="float:left;"><i class="fa fa-users" aria-hidden="true" style="padding:5px; background:grey; color:black; border-radius:5px; margin-right:5px;"></i> <?php echo $row["title"]." | ".$row["year"]; ?></span>
								<span style="float:right;"><?php echo $row["duration"]; ?></span>
							</div>
							
							<div class="col-md-12" style="background:grey; padding:10px; width:100%; border-bottom-right-radius:10px; border-bottom-left-radius:10px;">
								<span style="float:left; color:black; font-weight:bold; font-size:14px;"><?php echo $row["artist"]; ?></span>
								<span style="float:right; color:black; text-transform:uppercase;"><?php echo $row["genre"]; ?></span>
								<br><br>
								<p style="text-align:justify; color:black;">Lorem ipsum dolor sit amet, connsectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo connsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
								
							</div>
						
							
						</div>
					
					
					
					
				<?php   } ?>



	<?php		
	 
	
	$msgAll = array();
	$sql = "SELECT * from songs where id>$idN limit 5";
	$msgAll = array();
	$result = mysqli_query ($conn,$sql); 
	while($row = mysqli_fetch_array($result)){
		$msgAll[] = $row;
	}
	 

	
	$allNumRows = count($msgAll);
	?>
	<?php if($allNumRows > 0){ ?>
	<div id="moreBN" style="text-align: center;" class="col-md-12"><a onclick="more(<?php echo $idN; ?>)" class="moreSongs">Load more...</a></div>
	

	<?php }else{ ?>
	<div id="moreBN" style="display:none;text-align: center;" class="col-md-12"><a onclick="more(<?php echo $idN; ?>)" class="moreSongs">Load more...</a></div>
	
	<?php } ?>