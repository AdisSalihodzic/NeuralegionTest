-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2019 at 07:12 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `neuralegion`
--

-- --------------------------------------------------------

--
-- Table structure for table `songs`
--

CREATE TABLE `songs` (
  `id` int(11) NOT NULL,
  `title` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `artist` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `duration` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `genre` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(55) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `songs`
--

INSERT INTO `songs` (`id`, `title`, `artist`, `duration`, `genre`, `year`) VALUES
(1, 'Sama si', 'Divlje jagode', '3:35', 'rock', '2019'),
(2, 'Karta do proslosti', 'Opca opasnost', '3:35', 'pop rock', '2019'),
(3, 'Jedina', 'Tose Proeski', '3:36', 'pop', '2000'),
(4, 'Zauvijek tvoj', 'Divlje jagode', '3:35', 'rock', '2018'),
(5, 'Pratim te', 'Tose Proeski', '3:35', 'pop', '2008'),
(6, 'Kad bi nestala', 'Retro', '3:34', 'pop rock', '2020'),
(7, 'Zasto krijes lice', 'Retro', '3:34', 'rock', '2019'),
(8, 'Djevojka iz snova', 'Plavi orkestar', '3:34', 'pop folk', '1999'),
(9, 'Azra', 'Plavi orkestar', '3:34', 'pop', '2002'),
(10, 'Tuga ti i ja', 'Crvena jabuka', '3:34', 'pop', '2003'),
(11, 'Do neba', 'Crvena jabuka', '3:34', 'pop', '2008'),
(12, 'Neko te ima nocas', 'Van gogh', '3:34', 'rock', '2009'),
(13, 'Spisak razloga', 'Van gogh', '3:34', 'rock', '2009'),
(14, 'Kad si rekla da me volis', 'Dino merlin', '3:34', 'pop', '2007'),
(15, 'Ruza', 'Dino Merlin', '3:34', 'pop', '2007');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `songs`
--
ALTER TABLE `songs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `songs`
--
ALTER TABLE `songs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
