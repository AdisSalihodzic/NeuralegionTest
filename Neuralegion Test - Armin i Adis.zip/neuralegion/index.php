<?php

	include 'db_connection.php';
	
?>

<!DOCTYPE html>

<head>

	<title>Neuralegion Test</title>
	
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<style>
	
		.selectBox{
			padding:5px;
			width:100%;
		}
		
		h1,h3{
			font-weight:bold;
		}
		
		.moreSongs{
			background:grey;
			padding:10px 15px;
			color:white;
			border-radius:10px;
		}
		
		.moreSongs:hover{
			text-decoration:none;
			cursor:pointer;
			color:black;
		}
	
	</style>

</head>

<body>

	<div class="col-md-8" style="padding:20px;" id="content">
	
	<?php
		
		$sql="SELECT * FROM songs LIMIT 5";
		$result=mysqli_query($conn,$sql);
		$id="";
		while($row = mysqli_fetch_array($result)){	
		$id=$row["id"];			
	?>

		<div class="col-md-12" style="margin-bottom:20px; border:1px solid grey; border-radius:10px; padding-left:0px!important; padding-right:0px!important;">
		
			<div class="col-md-12" style="padding:10px; width:100%;">
				<span style="float:left;"><i class="fa fa-users" aria-hidden="true" style="padding:5px; background:grey; color:black; border-radius:5px; margin-right:5px;"></i> <?php echo $row["title"]." | ".$row["year"]; ?></span>
				<span style="float:right;"><?php echo $row["duration"]; ?></span>
			</div>
			
			<div class="col-md-12" style="background:grey; padding:10px; width:100%; border-bottom-right-radius:10px; border-bottom-left-radius:10px;">
				<span style="float:left; color:black; font-weight:bold; font-size:14px;"><?php echo $row["artist"]; ?></span>
				<span style="float:right; color:black; text-transform:uppercase;"><?php echo $row["genre"]; ?></span>
				<br><br>
				<p style="text-align:justify; color:black;">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
				
			</div>
		
			
		</div>
		
	<?php
		}
	?>
	
	<?php 
			
		echo '<div id="moreBN" style="text-align: center;" class="col-md-12 wow bounceInUp" data-wow-duration="1.5s" data-wow-delay="0s"><a onclick="more('.$id.')" class="moreSongs">Load more...</a></div>';
		
	?>
		
		<input type="hidden" id="prikazijos" value="<?php echo $idN12; ?>">
		<p id="loadingg" style="display:none;">Load more...</p>
		<div id="loadmoreBN" class="row"></div>
	
	</div>
	
	<div class="col-md-4" style="background:grey; height:100vh; position:fixed; right:0px;">
	
		<h1>Filter</h1>
		
		<h3>Artist</h3>
		<select class="selectBox" name="artist" id="artist" onchange="filter('artist')">
			<option value="all">All</option>
			<?php
		
				$sql="SELECT * FROM songs";
				$result=mysqli_query($conn,$sql);
				$artists=array();
				while($row = mysqli_fetch_array($result)){	
					if(!in_array($row["artist"],$artists)){
						array_push($artists,$row["artist"]);
					}
				}
				
				foreach($artists as $artist){
			?>
			
					<option value="<?php echo $artist; ?>"><?php echo $artist; ?></option>
			
			<?php
				}
			?>
			
		</select>
		
		<h3>Genre</h3>
		<select class="selectBox" name="genre" id="genre" onchange="filter('genre')">
			<option value="all">All</option>
			<?php
		
				$sql="SELECT * FROM songs";
				$result=mysqli_query($conn,$sql);
				$genres=array();
				while($row = mysqli_fetch_array($result)){	
					if(!in_array($row["genre"],$genres)){
						array_push($genres,$row["genre"]);
					}
				}
				
				foreach($genres as $genre){
			?>
			
					<option value="<?php echo $genre; ?>"><?php echo $genre; ?></option>
			
			<?php
				}
			?>
		</select>
		
		<h3>Year</h3>
		<select class="selectBox" name="year" id="year" onchange="filter('year')">
			<option value="all">All</option>
			<?php
		
				$sql="SELECT * FROM songs";
				$result=mysqli_query($conn,$sql);
				$years=array();
				while($row = mysqli_fetch_array($result)){	
					if(!in_array($row["year"],$years)){
						array_push($years,$row["year"]);
					}
				}
				
				foreach($years as $year){
			?>
			
					<option value="<?php echo $year; ?>"><?php echo $year; ?></option>
			
			<?php
				}
			?>
		</select>
	
	</div>

</body>

<script>

	function filter(id){
		
		var filterBy = id;
		var filterValue = $("#"+id).val();
		
		if(filterBy=="artist"){
			$("#genre").val("all");
			$("#year").val("all");
		}
		else if(filterBy=="genre"){
			$("#artist").val("all");
			$("#year").val("all");
		}
		else{
			$("#genre").val("all");
			$("#artist").val("all");
		}
		
		$.ajax({
			type:'GET',
			url: "filter.php?id="+filterBy+"&&val="+filterValue,
			beforeSend:function(){
				
			},
			success:function(html){
				$('#content').empty();
				$('#content').append(html);				
			},error:function(html){
				console.log(html);
			}
		});
	}

</script>

<script>

        function more(prikazi){
		
		
		
		 $.ajax({
							type:'GET',
							url: "load.php?id="+prikazi,
							beforeSend:function(){
								$('#moreBN').remove();
							},
							success:function(html){
								$('#loadmoreBN').append(html);
							},error:function(html){
								console.log(html);
							}
						}); 
		
		
	}
</script>

</html>